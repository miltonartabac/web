<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" dir="ltr" lang="es-ES">
    <head>

	<!-- Google tag (gtag.js) -->
	<script async src="https://www.googletagmanager.com/gtag/js?id=G-QFD0G9S62Y"></script>
	<script>
  		window.dataLayer = window.dataLayer || [];
  		function gtag(){dataLayer.push(arguments);}
  		gtag('js', new Date());

  		gtag('config', 'G-QFD0G9S62Y');
	</script>

        
<meta http-equiv="Content-type" content="text/html; charset=utf-8" />

<title>Shop Conexall</title>
<meta name="title" content="Shop Conexall" />
<meta name="description" content="Catálogo de productos" />
<meta http-equiv="Cache-Control" content="no-cache" />
<meta http-equiv="Expires" content="Fri, Jan 01 1970 00:00:00 GMT" />

<meta name="viewport" content="initial-scale = 1.0,maximum-scale = 1.0" />

<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-status-bar-style" content="black">

<!-- favicon -->
<link rel="shortcut icon" href="https://shop.conexall.com/oc-content/themes/bender/favicon/favicon-48.png">
<link rel="apple-touch-icon-precomposed" sizes="144x144" href="https://shop.conexall.com/oc-content/themes/bender/favicon/favicon-144.png">
<link rel="apple-touch-icon-precomposed" sizes="114x114" href="https://shop.conexall.com/oc-content/themes/bender/favicon/favicon-114.png">
<link rel="apple-touch-icon-precomposed" sizes="72x72" href="https://shop.conexall.com/oc-content/themes/bender/favicon/favicon-72.png">
<link rel="apple-touch-icon-precomposed" href="https://shop.conexall.com/oc-content/themes/bender/favicon/favicon-57.png">
<!-- /favicon -->

<link href="https://shop.conexall.com/oc-content/themes/bender/js/jquery-ui/jquery-ui-1.10.2.custom.min.css" rel="stylesheet" type="text/css" />

<script type="text/javascript">
    var bender = window.bender || {};
    bender.base_url = 'https://shop.conexall.com/index.php';
    bender.langs = {"delete":"Eliminar","cancel":"Cancelar"};
    bender.fancybox_prev = 'Imagen anterior';
    bender.fancybox_next = 'Siguiente imagen';
    bender.fancybox_closeBtn = 'Cerrar';
</script>
<link href="https://shop.conexall.com/oc-content/themes/bender/css/main.css" rel="stylesheet" type="text/css" />
<meta name="generator" content="Osclass 5.1.2" /><meta name="robots" content="index, follow" />
<meta name="googlebot" content="index, follow" />
<script src="https://shop.conexall.com/oc-includes/assets/jquery/jquery.min.js"></script>
<script src="https://shop.conexall.com/oc-content/themes/bender/js/fancybox/js/jquery.fancybox.min.js"></script>
<script src="https://shop.conexall.com/oc-includes/assets/osclass-legacy/js/date.js"></script>
<script src="https://shop.conexall.com/oc-includes/assets/osclass-legacy/js/fineuploader/jquery.fineuploader.min.js"></script>
<script src="https://shop.conexall.com/oc-includes/assets/jquery-ui/jquery-ui.min.js"></script>
<script src="https://shop.conexall.com/oc-content/themes/bender/js/global.js"></script>
<link href="https://shop.conexall.com/oc-content/themes/bender/js/fancybox/css/jquery.fancybox.min.css" rel="stylesheet" type="text/css" />
<link href="https://shop.conexall.com/oc-content/themes/bender/css/font-awesome-4.1.0/css/font-awesome.min.css" rel="stylesheet" type="text/css" />
<link href="https://shop.conexall.com/oc-includes/assets/osclass-legacy/js/fineuploader/fineuploader.css" rel="stylesheet" type="text/css" />
<link href="https://shop.conexall.com/oc-content/themes/bender/css/ajax-uploader.css" rel="stylesheet" type="text/css" />

        <style>
		@media screen and (min-width: 800px) {
    			.ancho {width: max-content !important;}
		}
	</style>

    </head>
<body class="has-searchbox home">

<div id="header">
    <!-- header ad 728x60-->
    <div class="ads_header">
        <!-- /header ad 728x60-->
    </div>
    <div class="clear"></div>
    <div class="wrapper">
        <div id="logo">
            <a href="https://shop.conexall.com/">Shop Conexall</a>            <span id="description">Catálogo de productos</span>
        </div>
        <ul class="nav">
                                                    <li><a id="login_open" href="https://shop.conexall.com/index.php?page=login">Iniciar sesión</a></li>
                                                            </ul>

    </div>
        <form action="https://shop.conexall.com/index.php" method="get" class="search nocsrf" >
        <input type="hidden" name="page" value="search"/>
        <div class="main-search">
            <div class="cell">
                <input type="text" name="sPattern" id="query" class="input-text" value="" placeholder="Buscar..." />
            </div>
                            <div class="cell selector">
                    <select name="sCategory" id="id" type="select" class="form-select form-select-sm"><option value="">Elige una categoría</option><option value="98">Hogar y Ferretería</option>
<option value="97">Material de Oficina</option>
<option value="10">Tecnología</option>
<option value="94">Ropa y Belleza</option>
<option value="9">Carros y Motos</option>
</select>
                </div>
                <div class="cell reset-padding">
                            <button class="ui-button ui-button-big js-submit">Buscar</button>
            </div>
        </div>
        <div id="message-seach"></div>
    </form>
    </div>
<div class="wrapper wrapper-flash">
        </div>
<div class="wrapper" id="content">
        <div id="main" class='ancho' >
                                    <div class="cell_3 first_cel">            <ul class="r-list">
                <li>
                    <h1>
                                                                            <a class="category hogar-y-ferreteria"
                               href="https://shop.conexall.com/index.php?page=search&sCategory=98">Hogar y Ferretería</a> <span>(11)</span>
                                            </h1>
                                    </li>
            </ul>
                                    <ul class="r-list">
                <li>
                    <h1>
                                                                            <a class="category material-de-oficina" href="#">Material de Oficina</a>
                            <span>()</span>
                                            </h1>
                                    </li>
            </ul>
                        </div><div class="cell_3">            <ul class="r-list">
                <li>
                    <h1>
                                                                            <a class="category tecnologia_1"
                               href="https://shop.conexall.com/index.php?page=search&sCategory=10">Tecnología</a> <span>(70)</span>
                                            </h1>
                                    </li>
            </ul>
                                    <ul class="r-list">
                <li>
                    <h1>
                                                                            <a class="category ropa-y-belleza"
                               href="https://shop.conexall.com/index.php?page=search&sCategory=94">Ropa y Belleza</a> <span>(23)</span>
                                            </h1>
                                    </li>
            </ul>
                        </div><div class="cell_3">            <ul class="r-list">
                <li>
                    <h1>
                                                                            <a class="category veiculos"
                               href="https://shop.conexall.com/index.php?page=search&sCategory=9">Carros y Motos</a> <span>(6)</span>
                                            </h1>
                                    </li>
            </ul>
            </div>                <div class="clear"></div>
<div class="latest_ads">
<h1><strong>Últimos productos</strong></h1>
     <div class="actions">
      <span class="doublebutton active">
           <a href="https://shop.conexall.com/index.php?sShowAs=list" class="list-button" data-class-toggle="listing-grid" data-destination="#listing-card-list"><span>Lista</span></a>
           <a href="https://shop.conexall.com/index.php?sShowAs=gallery" class="grid-button" data-class-toggle="listing-grid" data-destination="#listing-card-list"><span>Rejilla</span></a>
      </span>
    </div>
    
<ul class="listing-card-list listing-grid" id="listing-card-list">
    
<li class="listing-card first">
                <a class="listing-thumb" href="https://shop.conexall.com/index.php?page=item&id=168" title="Receptor Bluethoot Auxiliar"><img src="https://shop.conexall.com/oc-content/uploads/1/448_thumbnail.jpg" title="" alt="Receptor Bluethoot Auxiliar" width="240" height="200"></a>
                <div class="listing-detail">
        <div class="listing-cell">
            <div class="listing-data">
                <div class="listing-basicinfo">
                    <a href="https://shop.conexall.com/index.php?page=item&id=168" class="title" title="Receptor Bluethoot Auxiliar">Receptor Bluethoot Auxiliar</a>
                    <div class="listing-attributes">
                        <span class="category">Estado: Nuevo</span>
                        <!-- <span class="location">La Lisa  (La Habana)</span> <span class="g-hide">-</span> Febrero 18, 2024 -->
                        				<span class="currency-value">
					10.00 USD <span style='color: darkgoldenrod'> (3000 CUP)</span>				</span>
			                    </div>
                    <p > Renueva tu vieja reproductora de carro o viejo equipo de música con este adaptador blethooth que permite reproducir la música de tu teléfono sin cables!</p>
                </div>
                            </div>
        </div>
    </div>
</li>

<li class="listing-card ">
                <a class="listing-thumb" href="https://shop.conexall.com/index.php?page=item&id=167" title="Linterna de cabeza"><img src="https://shop.conexall.com/oc-content/uploads/1/444_thumbnail.jpg" title="" alt="Linterna de cabeza" width="240" height="200"></a>
                <div class="listing-detail">
        <div class="listing-cell">
            <div class="listing-data">
                <div class="listing-basicinfo">
                    <a href="https://shop.conexall.com/index.php?page=item&id=167" class="title" title="Linterna de cabeza">Linterna de cabeza</a>
                    <div class="listing-attributes">
                        <span class="category">Estado: Nuevo</span>
                        <!-- <span class="location">La Lisa  (La Habana)</span> <span class="g-hide">-</span> Febrero 18, 2024 -->
                        				<span class="currency-value">
					4.00 USD <span style='color: darkgoldenrod'> (1200 CUP)</span>				</span>
			                    </div>
                    <p > Linterna de cabeza, para mecaniquear, pezca, camping, trabajos con poca luz, etc. Lleva 3 pilas AAA. No se incluyen.</p>
                </div>
                            </div>
        </div>
    </div>
</li>

<li class="listing-card ">
                <a class="listing-thumb" href="https://shop.conexall.com/index.php?page=item&id=166" title="Interruptor Fotoeléctrico"><img src="https://shop.conexall.com/oc-content/uploads/1/438_thumbnail.jpg" title="" alt="Interruptor Fotoeléctrico" width="240" height="200"></a>
                <div class="listing-detail">
        <div class="listing-cell">
            <div class="listing-data">
                <div class="listing-basicinfo">
                    <a href="https://shop.conexall.com/index.php?page=item&id=166" class="title" title="Interruptor Fotoeléctrico">Interruptor Fotoeléctrico</a>
                    <div class="listing-attributes">
                        <span class="category">Estado: Nuevo</span>
                        <!-- <span class="location">La Lisa  (La Habana)</span> <span class="g-hide">-</span> Febrero 18, 2024 -->
                        				<span class="currency-value">
					10.00 USD <span style='color: darkgoldenrod'> (3000 CUP)</span>				</span>
			                    </div>
                    <p > Para automatizar el encendido de las luces al caer la noche. Modelo AS-10 Interruptor De Control De Luz Automático Para Farolas 110V 10A</p>
                </div>
                            </div>
        </div>
    </div>
</li>

<li class="listing-card ">
                <a class="listing-thumb" href="https://shop.conexall.com/index.php?page=item&id=108" title="Android TV Box T95Z Plus"><img src="https://shop.conexall.com/oc-content/uploads/1/283_thumbnail.jpg" title="" alt="Android TV Box T95Z Plus" width="240" height="200"></a>
                <div class="listing-detail">
        <div class="listing-cell">
            <div class="listing-data">
                <div class="listing-basicinfo">
                    <a href="https://shop.conexall.com/index.php?page=item&id=108" class="title" title="Android TV Box T95Z Plus">Android TV Box T95Z Plus</a>
                    <div class="listing-attributes">
                        <span class="category">Estado: Nuevo</span>
                        <!-- <span class="location">La Lisa  (La Habana)</span> <span class="g-hide">-</span> Febrero 18, 2024 -->
                        				<span class="currency-value">
					85.00 USD <span style='color: darkgoldenrod'> (25500 CUP)</span>				</span>
			                    </div>
                    <p > Convierte los televisores tradicionales en Smart TVs con Android TV incorporado. A través de un cable de conexión HDMI, se conecta al televisor para convertirlo en un televisor inteligente con las funciones de Android TV. Incluye cable HDMI Mando de ...</p>
                </div>
                            </div>
        </div>
    </div>
</li>

<li class="listing-card ">
                <a class="listing-thumb" href="https://shop.conexall.com/index.php?page=item&id=165" title="Xiaomi TV Box S 2nd Gen"><img src="https://shop.conexall.com/oc-content/uploads/1/435_thumbnail.jpg" title="" alt="Xiaomi TV Box S 2nd Gen" width="240" height="200"></a>
                <div class="listing-detail">
        <div class="listing-cell">
            <div class="listing-data">
                <div class="listing-basicinfo">
                    <a href="https://shop.conexall.com/index.php?page=item&id=165" class="title" title="Xiaomi TV Box S 2nd Gen">Xiaomi TV Box S 2nd Gen</a>
                    <div class="listing-attributes">
                        <span class="category">Estado: Nuevo</span>
                        <!-- <span class="location">La Lisa  (La Habana)</span> <span class="g-hide">-</span> Febrero 18, 2024 -->
                        				<span class="currency-value">
					100.00 USD <span style='color: darkgoldenrod'> (30000 CUP)</span>				</span>
			                    </div>
                    <p > Xiaomi TV Box S (2nd Gen) 4K Ultra HD Streaming Media Player • Google TV Box • with 2GB RAM 8GB ROM • 2.4G/5G Dual WiFi • Bluetooth 5.2 &amp; Dolby Atmos &amp; DTS-HD • Dolby Vision • HDR10+ Calidad de imagen 4K Ultra HD: 4K Ultra HD realiza una imag...</p>
                </div>
                            </div>
        </div>
    </div>
</li>

<li class="listing-card first">
                <a class="listing-thumb" href="https://shop.conexall.com/index.php?page=item&id=9" title="Flash USB 64Gb Kingston Exodia"><img src="https://shop.conexall.com/oc-content/uploads/0/14_thumbnail.jpg" title="" alt="Flash USB 64Gb Kingston Exodia" width="240" height="200"></a>
                <div class="listing-detail">
        <div class="listing-cell">
            <div class="listing-data">
                <div class="listing-basicinfo">
                    <a href="https://shop.conexall.com/index.php?page=item&id=9" class="title" title="Flash USB 64Gb Kingston Exodia">Flash USB 64Gb Kingston Exodia</a>
                    <div class="listing-attributes">
                        <span class="category">Estado: Nuevo</span>
                        <!-- <span class="location">La Lisa  (La Habana)</span> <span class="g-hide">-</span> Febrero 18, 2024 -->
                        				<span class="currency-value">
					9.00 USD <span style='color: darkgoldenrod'> (2700 CUP)</span>				</span>
			                    </div>
                    <p > DataTraveler® Exodia™ de Kingston es una solución de almacenamiento compatible con USB 3.2 Gen 1 para portátiles, equipos de sobremesa, monitores y otros dispositivos digitales. DT Exodia permite rápidas transferencias y facilita el almacenamiento de...</p>
                </div>
                            </div>
        </div>
    </div>
</li>

<li class="listing-card ">
                <a class="listing-thumb" href="https://shop.conexall.com/index.php?page=item&id=5" title="Adaptador de Red USB3 1000mb"><img src="https://shop.conexall.com/oc-content/uploads/0/21_thumbnail.jpg" title="" alt="Adaptador de Red USB3 1000mb" width="240" height="200"></a>
                <div class="listing-detail">
        <div class="listing-cell">
            <div class="listing-data">
                <div class="listing-basicinfo">
                    <a href="https://shop.conexall.com/index.php?page=item&id=5" class="title" title="Adaptador de Red USB3 1000mb">Adaptador de Red USB3 1000mb</a>
                    <div class="listing-attributes">
                        <span class="category">Estado: Nuevo</span>
                        <!-- <span class="location">La Lisa  (La Habana)</span> <span class="g-hide">-</span> Febrero 18, 2024 -->
                        				<span class="currency-value">
					15.00 USD <span style='color: darkgoldenrod'> (4500 CUP)</span>				</span>
			                    </div>
                    <p > Tarjeta de red USB o Adaptador de red USB con su puerto RJ45. Para quien no tenga este puerto o se le haya roto. 1000Mb/s.</p>
                </div>
                            </div>
        </div>
    </div>
</li>

<li class="listing-card ">
                <a class="listing-thumb" href="https://shop.conexall.com/index.php?page=item&id=164" title="Xiaomi Redmi Buds 4 Lite"><img src="https://shop.conexall.com/oc-content/uploads/1/431_thumbnail.jpg" title="" alt="Xiaomi Redmi Buds 4 Lite" width="240" height="200"></a>
                <div class="listing-detail">
        <div class="listing-cell">
            <div class="listing-data">
                <div class="listing-basicinfo">
                    <a href="https://shop.conexall.com/index.php?page=item&id=164" class="title" title="Xiaomi Redmi Buds 4 Lite">Xiaomi Redmi Buds 4 Lite</a>
                    <div class="listing-attributes">
                        <span class="category">Estado: Nuevo</span>
                        <!-- <span class="location">La Lisa  (La Habana)</span> <span class="g-hide">-</span> Febrero 18, 2024 -->
                        				<span class="currency-value">
					35.00 USD <span style='color: darkgoldenrod'> (10500 CUP)</span>				</span>
			                    </div>
                    <p > Batería: 35mAh (auriculares / 320mAh (carcasa) Autonomía: Hasta 5horas. Autonomía máxima: hasta 20h con la carcasa. Puerto de carga: USB-C. Tiempo de Carga: Menos de 2 Horas. Conectividad: Bluetooth 5.3 Peso: 3.8gr el auricular / 35 gramos en total. ...</p>
                </div>
                            </div>
        </div>
    </div>
</li>

<li class="listing-card ">
                <a class="listing-thumb" href="https://shop.conexall.com/index.php?page=item&id=14" title="Cable carga Miband 5 y 6"><img src="https://shop.conexall.com/oc-content/uploads/0/26_thumbnail.jpg" title="" alt="Cable carga Miband 5 y 6" width="240" height="200"></a>
                <div class="listing-detail">
        <div class="listing-cell">
            <div class="listing-data">
                <div class="listing-basicinfo">
                    <a href="https://shop.conexall.com/index.php?page=item&id=14" class="title" title="Cable carga Miband 5 y 6">Cable carga Miband 5 y 6</a>
                    <div class="listing-attributes">
                        <span class="category">Estado: Nuevo</span>
                        <!-- <span class="location">La Lisa  (La Habana)</span> <span class="g-hide">-</span> Febrero 18, 2024 -->
                        				<span class="currency-value">
					3.00 USD <span style='color: darkgoldenrod'> (900 CUP)</span>				</span>
			                    </div>
                    <p > Cable de carga para Xiaomi MiBand 5 y 6.</p>
                </div>
                            </div>
        </div>
    </div>
</li>

<li class="listing-card ">
                <a class="listing-thumb" href="https://shop.conexall.com/index.php?page=item&id=163" title="Chasis pa inventar"><img src="https://shop.conexall.com/oc-content/uploads/1/428_thumbnail.jpg" title="" alt="Chasis pa inventar" width="240" height="200"></a>
                <div class="listing-detail">
        <div class="listing-cell">
            <div class="listing-data">
                <div class="listing-basicinfo">
                    <a href="https://shop.conexall.com/index.php?page=item&id=163" class="title" title="Chasis pa inventar">Chasis pa inventar</a>
                    <div class="listing-attributes">
                        <span class="category">Estado: Pa resolver</span>
                        <!-- <span class="location">La Lisa  (La Habana)</span> <span class="g-hide">-</span> Febrero 11, 2024 -->
                        				<span class="currency-value">
					3.00 USD <span style='color: darkgoldenrod'> (900 CUP)</span>				</span>
			                    </div>
                    <p > Chasis de formato pequeño. Tiene panel frontal con 2x USB, Audio, Lector de tarjeta, Receptor IR y pequeña bocina. Trae un Fan Frontal.Tiene unos plásticos partidos de la tapa frontal que no queda 100% agarrado bien.</p>
                </div>
                            </div>
        </div>
    </div>
</li>

<li class="listing-card first">
                <a class="listing-thumb" href="https://shop.conexall.com/index.php?page=item&id=162" title="Gafas de Soldar"><img src="https://shop.conexall.com/oc-content/uploads/1/424_thumbnail.jpg" title="" alt="Gafas de Soldar" width="240" height="200"></a>
                <div class="listing-detail">
        <div class="listing-cell">
            <div class="listing-data">
                <div class="listing-basicinfo">
                    <a href="https://shop.conexall.com/index.php?page=item&id=162" class="title" title="Gafas de Soldar">Gafas de Soldar</a>
                    <div class="listing-attributes">
                        <span class="category">Estado: Nuevo</span>
                        <!-- <span class="location">La Lisa  (La Habana)</span> <span class="g-hide">-</span> Febrero 11, 2024 -->
                        				<span class="currency-value">
					12.00 USD <span style='color: darkgoldenrod'> (3600 CUP)</span>				</span>
			                    </div>
                    <p > Gafas De Soldadura De Oscurecimiento Automático. No requieren baterías.</p>
                </div>
                            </div>
        </div>
    </div>
</li>

<li class="listing-card ">
                <a class="listing-thumb" href="https://shop.conexall.com/index.php?page=item&id=63" title="Plato ducha 20cm"><img src="https://shop.conexall.com/oc-content/uploads/0/148_thumbnail.jpg" title="" alt="Plato ducha 20cm" width="240" height="200"></a>
                <div class="listing-detail">
        <div class="listing-cell">
            <div class="listing-data">
                <div class="listing-basicinfo">
                    <a href="https://shop.conexall.com/index.php?page=item&id=63" class="title" title="Plato ducha 20cm">Plato ducha 20cm</a>
                    <div class="listing-attributes">
                        <span class="category">Estado: Nuevo</span>
                        <!-- <span class="location">La Lisa  (La Habana)</span> <span class="g-hide">-</span> Febrero 11, 2024 -->
                        				<span class="currency-value">
					20.00 USD <span style='color: darkgoldenrod'> (6000 CUP)</span>				</span>
			                    </div>
                    <p > Plato de ducha grande metálico de 20 cm de diámetro y salidas engomadas para limpieza fácil de obstrucciones.</p>
                </div>
                            </div>
        </div>
    </div>
</li>

<li class="listing-card ">
                <a class="listing-thumb" href="https://shop.conexall.com/index.php?page=item&id=161" title="Linterna de cabeza"><img src="https://shop.conexall.com/oc-content/uploads/1/416_thumbnail.jpg" title="" alt="Linterna de cabeza" width="240" height="200"></a>
                <div class="listing-detail">
        <div class="listing-cell">
            <div class="listing-data">
                <div class="listing-basicinfo">
                    <a href="https://shop.conexall.com/index.php?page=item&id=161" class="title" title="Linterna de cabeza">Linterna de cabeza</a>
                    <div class="listing-attributes">
                        <span class="category">Estado: Nuevo</span>
                        <!-- <span class="location">La Lisa  (La Habana)</span> <span class="g-hide">-</span> Febrero 11, 2024 -->
                        				<span class="currency-value">
					8.00 USD <span style='color: darkgoldenrod'> (2400 CUP)</span>				</span>
			                    </div>
                    <p > Linterna de cabeza, para mecaniquear, pezca, camping, trabajos con poca luz, etc. Batería integrada, recargable por USB.</p>
                </div>
                            </div>
        </div>
    </div>
</li>

<li class="listing-card ">
                <a class="listing-thumb" href="https://shop.conexall.com/index.php?page=item&id=160" title="Conector BNC"><img src="https://shop.conexall.com/oc-content/uploads/1/415_thumbnail.jpg" title="" alt="Conector BNC" width="240" height="200"></a>
                <div class="listing-detail">
        <div class="listing-cell">
            <div class="listing-data">
                <div class="listing-basicinfo">
                    <a href="https://shop.conexall.com/index.php?page=item&id=160" class="title" title="Conector BNC">Conector BNC</a>
                    <div class="listing-attributes">
                        <span class="category">Estado: Nuevo</span>
                        <!-- <span class="location">La Lisa  (La Habana)</span> <span class="g-hide">-</span> Febrero 10, 2024 -->
                        				<span class="currency-value">
					2.00 USD <span style='color: darkgoldenrod'> (600 CUP)</span>				</span>
			                    </div>
                    <p > Conector BNC</p>
                </div>
                            </div>
        </div>
    </div>
</li>

<li class="listing-card ">
                <a class="listing-thumb" href="https://shop.conexall.com/index.php?page=item&id=159" title="Cable BNC a BNC"><img src="https://shop.conexall.com/oc-content/uploads/1/413_thumbnail.jpg" title="" alt="Cable BNC a BNC" width="240" height="200"></a>
                <div class="listing-detail">
        <div class="listing-cell">
            <div class="listing-data">
                <div class="listing-basicinfo">
                    <a href="https://shop.conexall.com/index.php?page=item&id=159" class="title" title="Cable BNC a BNC">Cable BNC a BNC</a>
                    <div class="listing-attributes">
                        <span class="category">Estado: Como nuevo</span>
                        <!-- <span class="location">La Lisa  (La Habana)</span> <span class="g-hide">-</span> Febrero 10, 2024 -->
                        				<span class="currency-value">
					5.00 USD <span style='color: darkgoldenrod'> (1500 CUP)</span>				</span>
			                    </div>
                    <p > Cable coaxial BNC Macho a BNC Macho, 50 ohm, varias medidas de 70cm (5usd), 1m (6usd), 1,7m (7usd), 5m (15usd)</p>
                </div>
                            </div>
        </div>
    </div>
</li>

<li class="listing-card first">
                <a class="listing-thumb" href="https://shop.conexall.com/index.php?page=item&id=158" title="Uniones BNC"><img src="https://shop.conexall.com/oc-content/uploads/1/411_thumbnail.jpg" title="" alt="Uniones BNC" width="240" height="200"></a>
                <div class="listing-detail">
        <div class="listing-cell">
            <div class="listing-data">
                <div class="listing-basicinfo">
                    <a href="https://shop.conexall.com/index.php?page=item&id=158" class="title" title="Uniones BNC">Uniones BNC</a>
                    <div class="listing-attributes">
                        <span class="category">Estado: Nuevo</span>
                        <!-- <span class="location">La Lisa  (La Habana)</span> <span class="g-hide">-</span> Febrero 10, 2024 -->
                        				<span class="currency-value">
					2.00 USD <span style='color: darkgoldenrod'> (600 CUP)</span>				</span>
			                    </div>
                    <p > Uniones para empalmar dos cables con conector BNC Macho.</p>
                </div>
                            </div>
        </div>
    </div>
</li>

<li class="listing-card ">
                <a class="listing-thumb" href="https://shop.conexall.com/index.php?page=item&id=157" title="Cable coaxial N Macho"><img src="https://shop.conexall.com/oc-content/uploads/1/409_thumbnail.jpg" title="" alt="Cable coaxial N Macho" width="240" height="200"></a>
                <div class="listing-detail">
        <div class="listing-cell">
            <div class="listing-data">
                <div class="listing-basicinfo">
                    <a href="https://shop.conexall.com/index.php?page=item&id=157" class="title" title="Cable coaxial N Macho">Cable coaxial N Macho</a>
                    <div class="listing-attributes">
                        <span class="category">Estado: Como nuevo</span>
                        <!-- <span class="location">La Lisa  (La Habana)</span> <span class="g-hide">-</span> Febrero 10, 2024 -->
                        				<span class="currency-value">
					12.00 USD <span style='color: darkgoldenrod'> (3600 CUP)</span>				</span>
			                    </div>
                    <p > Cable coaxial de baja pérdida 1.5 Metros, 50 ohm, N Macho a N Macho. Para antenas WIFI o equipos similares de telecomunicaciones.</p>
                </div>
                            </div>
        </div>
    </div>
</li>

<li class="listing-card ">
                <a class="listing-thumb" href="https://shop.conexall.com/index.php?page=item&id=156" title="Blusa Talla M"><img src="https://shop.conexall.com/oc-content/uploads/1/401_thumbnail.jpg" title="" alt="Blusa Talla M" width="240" height="200"></a>
                <div class="listing-detail">
        <div class="listing-cell">
            <div class="listing-data">
                <div class="listing-basicinfo">
                    <a href="https://shop.conexall.com/index.php?page=item&id=156" class="title" title="Blusa Talla M">Blusa Talla M</a>
                    <div class="listing-attributes">
                        <span class="category">Estado: Nuevo</span>
                        <!-- <span class="location">La Lisa  (La Habana)</span> <span class="g-hide">-</span> Febrero 2, 2024 -->
                        				<span class="currency-value">
					9.00 USD <span style='color: darkgoldenrod'> (2700 CUP)</span>				</span>
			                    </div>
                    <p > Talla M, solo incluye la blusa</p>
                </div>
                            </div>
        </div>
    </div>
</li>

<li class="listing-card ">
                <a class="listing-thumb" href="https://shop.conexall.com/index.php?page=item&id=155" title="Blusa Talla XS"><img src="https://shop.conexall.com/oc-content/uploads/1/399_thumbnail.jpg" title="" alt="Blusa Talla XS" width="240" height="200"></a>
                <div class="listing-detail">
        <div class="listing-cell">
            <div class="listing-data">
                <div class="listing-basicinfo">
                    <a href="https://shop.conexall.com/index.php?page=item&id=155" class="title" title="Blusa Talla XS">Blusa Talla XS</a>
                    <div class="listing-attributes">
                        <span class="category">Estado: Nuevo</span>
                        <!-- <span class="location">La Lisa  (La Habana)</span> <span class="g-hide">-</span> Febrero 2, 2024 -->
                        				<span class="currency-value">
					9.00 USD <span style='color: darkgoldenrod'> (2700 CUP)</span>				</span>
			                    </div>
                    <p > Talla XS</p>
                </div>
                            </div>
        </div>
    </div>
</li>

<li class="listing-card ">
                <a class="listing-thumb" href="https://shop.conexall.com/index.php?page=item&id=154" title="Blusa Talla XS"><img src="https://shop.conexall.com/oc-content/uploads/1/397_thumbnail.jpg" title="" alt="Blusa Talla XS" width="240" height="200"></a>
                <div class="listing-detail">
        <div class="listing-cell">
            <div class="listing-data">
                <div class="listing-basicinfo">
                    <a href="https://shop.conexall.com/index.php?page=item&id=154" class="title" title="Blusa Talla XS">Blusa Talla XS</a>
                    <div class="listing-attributes">
                        <span class="category">Estado: Nuevo</span>
                        <!-- <span class="location">La Lisa  (La Habana)</span> <span class="g-hide">-</span> Febrero 2, 2024 -->
                        				<span class="currency-value">
					9.00 USD <span style='color: darkgoldenrod'> (2700 CUP)</span>				</span>
			                    </div>
                    <p > Talla XS</p>
                </div>
                            </div>
        </div>
    </div>
</li>
</ul>
    <div class="clear"></div>
            <p class="see_more_link"><a href="index.php?page=search&iPage=2">
            <strong>Más productos &raquo;</strong></a>
        </p>
    </div>
</div><!-- main -->
<!--
<div id="sidebar">
        <div class="widget-box">
                <div class="box location">
            <h3><strong>Ubicación</strong></h3>
            <ul>
                            <li><a href="https://shop.conexall.com/index.php?page=search&sRegion=29">La Habana <em>(110)</em></a></li>
                        </ul>
        </div>
            </div>
</div>
-->
<div class="clear"><!-- do not close, use main clossing tag for this case -->
</div><!-- content -->
</div>
<div id="responsive-trigger"></div>
<!-- footer -->
<div class="clear"></div>
<div id="footer">
    <div class="wrapper">
        <ul class="resp-toggle">
                                        <li><a href="https://shop.conexall.com/index.php?page=login">Iniciar sesión</a></li>
                                                            </ul>
        <ul>
                   <!-- <li>
                <a href="https://shop.conexall.com/index.php?page=contact">Contactar</a>
            </li> -->
        </ul>
                    </div>
</div>
</body></html>
